# DevianoDames_PortfolioMidterm

Welcome to my personal portfolio website! This website showcases my work as a Web & Motion Designer.

## Table of Contents
- [Introduction](#introduction)
- [Features](#features)
- [Getting Started](#getting-started)
- [Usage](#usage)
- [Technologies Used](#technologies-used)
- [License](#license)
- [Contact](#contact)

## Introduction

This is the portfolio website of Deviano Dames. It provides an overview of my background, projects, and how to get in touch with me.

## Features

- Responsive design for both mobile and desktop views
- Project showcase with navigation
- About Me section with social buttons
- Contact button to get in touch

# Usage

# Technologies Used
html5
css3
javaScript

# License
MIT License