<?php
//connect to the database
$connect = new mysqli('localhost','root','root','Deviano_Dames_portfolio');
?>